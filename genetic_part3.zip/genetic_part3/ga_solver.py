# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 2022

@author: tdrumond & agademer

Template file for your Exercise 3 submission 
(generic genetic algorithm module)
"""

import random  # Importing the random module for generating random numbers

class Individual:
    """Represents an Individual for a genetic algorithm"""

    def __init__(self, chromosome: list, fitness: float):
        """Initializes an Individual for a genetic algorithm

        Args:
            chromosome (list[]): a list representing the individual's chromosome
            fitness (float): the individual's fitness (the higher the value, the better the fitness)
        """
        self.chromosome = chromosome            # Initializing the chromosome attribute with the given chromosome
        self.fitness = fitness                  # Initializing the fitness attribute with the given fitness

    def __lt__(self, other):
        """Implementation of the less_than comparator operator"""
        return self.fitness < other.fitness

    def __repr__(self):
        """Representation of the object for print calls"""
        return f'Indiv({self.fitness:.1f},{self.chromosome})'       # String representation of the individual

class GAProblem:
    """Defines a Genetic algorithm problem to be solved by ga_solver"""

    def mutation(self, chromosome):
        """Perform mutation operation on individual's chromosome."""

    def create(self):
        """Generate a new chromosome."""

    def calculate_fitness(self, chromosome):
        """Evaluate the fitness of an individual."""

    def reproduction(self, parent1, parent2):
        """Perform crossover operation between parents' chromosomes."""
        

class GASolver:
    """Implements a genetic algorithm solver"""
    
    def __init__(self, problem: GAProblem, selection_rate=0.5, mutation_rate=0.1):
        """Initializes an instance of a ga_solver for a given GAProblem

        Args:
            problem (GAProblem): GAProblem to be solved by this ga_solver
            selection_rate (float, optional): Selection rate between 0 and 1.0. Defaults to 0.5.
            mutation_rate (float, optional): Mutation rate between 0 and 1.0. Defaults to 0.1.
        """
        self._problem = problem                     # Initializing the problem attribute with the given problem
        self._selection_rate = selection_rate       # Initializing the selection rate attribute
        self._mutation_rate = mutation_rate         # Initializing the mutation rate attribute
        self._population = []                       # Initializing an empty list for population

    def reset_population(self, pop_size=50):
        """Initialize the population with pop_size random Individuals."""
        for i in range(pop_size):                                   # Looping over the population size
            chromosome = self._problem.create()                     # Generating a new chromosome using the create method of the problem
            fitness = self._problem.calculate_fitness(chromosome)   # Calculating fitness for the chromosome
            new_individual = Individual(chromosome, fitness)        # Creating a new Individual object
            self._population.append(new_individual)                 # Adding the new Individual to the population list

    def evolve_for_one_generation(self):
        """Apply the process for one generation."""
        self._population.sort(reverse=True)                                     # Sorting the population in descending order of fitness
        num_to_remove = int(len(self._population) * self._selection_rate)       # Calculating the number of individuals to remove
        del self._population[-num_to_remove:]                                   # Removing the least fit individuals from the population
        for _ in range(num_to_remove):                                          # Looping over the number of removed individuals
            a_index, b_index = random.sample(range(num_to_remove), 2)           # Selecting two random indices
            a = self._population[a_index]                                       # Getting the Individual at index a_index
            b = self._population[b_index]                                       # Getting the Individual at index b_index
            new_chrom = self._problem.reproduction(a.chromosome, b.chromosome)  # Performing crossover operation
            if random.random() < self._mutation_rate:                           # Checking if mutation should occur
                new_chrom = self._problem.mutation(new_chrom)                   # Performing mutation operation
            fitness = self._problem.calculate_fitness(new_chrom)                # Calculating fitness for the new chromosome
            new_individual = Individual(new_chrom, fitness)                     # Creating a new Individual object
            self._population.append(new_individual)                             # Adding the new Individual to the population

    def show_generation_summary(self):
        """Print some debug information on the current state of the population."""
        avg_fitness = sum(individual.fitness for individual in self._population) / len(self._population)  # Calculating average fitness
        best_individual = max(self._population)                                                           # Finding the best individual
        worst_individual = min(self._population)                                                          # Finding the worst individual
        print(f"Generation Summary:")                                                                     # Printing header
        print(f"  - Average Fitness: {avg_fitness:.2f}")                                                  # Printing average fitness
        print(f"  - Best Individual: {best_individual}")                                                  # Printing best individual
        print(f"  - Worst Individual: {worst_individual}")                                                # Printing worst individual

    def get_best_individual(self):
        """Return the best Individual of the population."""
        return max(self._population)                            

    def evolve_until(self, max_nb_of_generations=500, threshold_fitness=None):
        """Launch the evolution process until termination conditions are met."""
        generation_count = 0                                                                                # Initializing generation count
        while generation_count < max_nb_of_generations:                                                     # Looping until maximum number of generations is reached
            if threshold_fitness is not None and self.get_best_individual().fitness >= threshold_fitness:   # Checking if threshold fitness is reached
                break                                                                                       # Exiting loop if threshold fitness is reached
            self.evolve_for_one_generation()                                                                # Evolving population for one generation
            generation_count += 1                                                                           # Incrementing generation count

        return self._population, generation_count                                                           # Returning final population and number of generations
