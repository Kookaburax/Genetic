# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 2022

@author: tdrumond & agademer

Template file for your Exercise 3 submission 
(GA solving Mastermind example)
"""
from ga_solver import GAProblem         # Importing GAProblem from ga_solver module
import mastermind as mm                 # Importing mastermind module as mm
import random                           # Importing the random module

class MastermindProblem(GAProblem):
    """Implementation of GAProblem for the Mastermind game"""

    def __init__(self, match):
        """Initialize the MastermindProblem instance with a MastermindMatch object.
        
        Args:
            match (MastermindMatch): An object representing a Mastermind game match.
        """
        self.match = match  
    
    def __str__(self):
        """Return a string representation of the MastermindProblem object."""
        return f"MastermindProblem with match: {self.match}"  

    def mutation(self, chromosome):
        """Perform mutation operation on an individual's chromosome."""
        valid_colors = mm.get_possible_colors()                              # Getting the list of possible colors
        pos = random.randrange(0, len(chromosome))                           # Generating a random position in the chromosome
        new_gene = random.choice(valid_colors)                               # Selecting a random color
        new_chromosome = chromosome[:pos] + [new_gene] + chromosome[pos+1:]  # Creating a new chromosome with mutation
        return new_chromosome                                                # Returning the mutated chromosome

    def create(self):
        """Generate a random chromosome."""
        return self.match.generate_random_guess() 

    def calculate_fitness(self, chromosome):
        """Calculate the fitness of an individual."""
        return self.match.rate_guess(chromosome)  

    def reproduction(self, parent1, parent2):
        """Perform crossover operation between parents' chromosomes."""
        x_point = random.randrange(0, len(parent1))             # Generating a random crossover point
        new_chromosome = parent1[:x_point] + parent2[x_point:]  # Creating a new chromosome by combining parent chromosomes
        return new_chromosome                                   # Returning the new chromosome

if __name__ == '__main__':
    from ga_solver import GASolver             # Importing GASolver from ga_solver module
    
    MATCH = mm.MastermindMatch(secret_size=6)  # Creating a MastermindMatch object with secret size 6
    problem = MastermindProblem(MATCH)         # Creating a MastermindProblem object with the match object
    solver = GASolver(problem)                 # Creating a GASolver object with the problem object
    
    solver.reset_population()                  # Call of Resetting the population
    solver.evolve_until()                      # Call of Evolving the population until 

    print(
        f"Best guess {mm.encode_guess(solver.get_best_individual().chromosome)} {solver.get_best_individual()}")    # Printing the best guess and individual
    print(
        f"Problem solved? {MATCH.is_correct(solver.get_best_individual().chromosome)}")                             # Checking if the problem is solved
    
    solver.show_generation_summary()                                                                                # Showing generation summary
