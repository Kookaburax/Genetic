# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 2022

@author: tdrumond & agademer

Template file for your Exercise 3 submission 
(GA solving TSP example)
"""
from ga_solver import GAProblem  # Importing GAProblem from ga_solver module
import cities                    # Importing cities module
import random                    # Importing random module

class TSProblem(GAProblem):
    """Implementation of GAProblem for the traveling salesperson problem"""

    def __init__(self, city_dict):
        """
        Initializes the TSProblem instance with a dictionary of cities.

        Args:
            city_dict (dict): Dictionary containing city names as keys and their coordinates as values.
        """
        self.city_dict = city_dict 

    def create(self):
        """
        Generates a random chromosome representing a possible tour.

        Returns:
            list: A list representing a chromosome (tour) of cities.
        """
        return list(self.city_dict.keys())  

    def calculate_fitness(self, chromosome):
        """
        Calculates the fitness of a given tour (chromosome) by summing the distances between consecutive cities.

        Args:
            chromosome (list): A list representing a tour of cities.

        Returns:
            float: The fitness value of the tour.
        """
        total_distance = 0                                                                       # Initializing the total distance
        for i in range(len(chromosome)):
            current_city = chromosome[i]
            next_city = chromosome[(i + 1) % len(chromosome)]                                    # Wrap around to the first city if last city reached
            distance = cities.distance(self.city_dict[current_city], self.city_dict[next_city])  # Calculating distance between current and next city
            total_distance += distance                                                           # Adding distance to total distance
        return 1 / total_distance                                                                # Inverting distance to represent fitness (higher fitness is better)

    def reproduction(self, parent1, parent2):
        """
        Performs crossover operation between parents' chromosomes (tours) using ordered crossover.

        Args:
            parent1 (list): Chromosome (tour) of parent 1.
            parent2 (list): Chromosome (tour) of parent 2.

        Returns:
            list: Offspring chromosome resulting from crossover.
        """
        offspring = [-1] * len(parent1)                  # Initializing offspring chromosome
        start_pos = random.randint(0, len(parent1) - 1)  # Generating random start position
        end_pos = random.randint(0, len(parent1) - 1)    # Generating random end position
        if start_pos < end_pos:
            for i in range(start_pos, end_pos + 1):      # Copying genes from parent1 within the range to offspring
                offspring[i] = parent1[i]
        else:
            for i in range(end_pos, start_pos + 1):      # Copying genes from parent1 within the range to offspring
                offspring[i] = parent1[i]

        for i in range(len(parent2)):
            if parent2[i] not in offspring:
                for j in range(len(offspring)):
                    if offspring[j] == -1:
                        offspring[j] = parent2[i]        # Copying genes from parent2 not present in offspring to offspring
                        break

        return offspring                                 # Returning the offspring chromosome resulting from crossover

    def mutation(self, chromosome):
        """
        Performs mutation operation on an individual's chromosome (tour) by swapping two cities.

        Args:
            chromosome (list): Chromosome (tour) to mutate.

        Returns:
            list: Mutated chromosome.
        """
        pos1, pos2 = random.sample(range(len(chromosome)), 2)                    # Selecting two random positions
        chromosome[pos1], chromosome[pos2] = chromosome[pos2], chromosome[pos1]  # Swapping cities at selected positions
        return chromosome                                                        # Returning the mutated chromosome

if __name__ == '__main__':
    from ga_solver import GASolver                                          # Importing GASolver from ga_solver module
    
    city_dict = cities.load_cities("cities.txt")                            # Load cities from file
    problem = TSProblem(city_dict)                                          # Initialize TSP problem with city dictionary
    solver = GASolver(problem)                                              # Initialize GASolver with TSP problem
    solver.reset_population()                                               # Generate initial population of tours
    solver.evolve_until()                                                   # Evolve the population until termination conditions are met
    cities.draw_cities(city_dict, solver.get_best_individual().chromosome)  # Draw the best tour found
    solver.show_generation_summary()                                        # Show generation summary
